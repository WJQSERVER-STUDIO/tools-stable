# WJQserver-tools-Stable
由WJQserver Studio推出的快捷Linux工具箱-稳定版本

V.0.9

```
wget -O tools-stable.sh https://raw.githubusercontent.com/WJQSERVER/tools-stable/main/tools-stable.sh && chmod +x tools-stable.sh && clear && ./tools-stable.sh
```

V.0.9 Mirror-US

```
wget -O tools-stable-mirror-us.sh https://tools.1888866.xyz/tools-stable-mirror-us.sh && chmod +x tools-stable-mirror-us.sh && clear && ./tools-stable-mirror-us.sh
```

# 声明

大部分功能非团队原创，部分功能仅提供辅助调用项目

不提供/保证任何功能的可用性，安全性，有效性，合法性

请确定你的用途符合 PRC(Mainland) USA 相关法律法规的要求和限制

请确定你的用途符合 你当地和运行环境/设备的 相关法律法规的要求和限制

# 维护中
部分功能还在测试
