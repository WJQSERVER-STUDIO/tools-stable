#! /bin/bash

#移动文件
mv main.sh /usr/local/bin/tools

#重载配置
source ~/.bashrc

#提示
echo "可以使用tools命令"